
This is the place where you might create your own unit tests (in Java or JRuby).
Just make sure NOT TO EDIT/RENAME the IntegrationTest.java file!

