
This is the place where you might create your own unit tests (in Java).
Just make sure NOT TO EDIT/RENAME the IntegrationTest.java file!
